<?php

$allOnOnePageTemplate = '0';

//define content type ('adult' / 'familySafe' / '40+' )
$contentType = 'adult';

//domain number (if we have more than one) - 0/1/2/3/... - "dev" for dev app
$appNumber = '1';

//activate or deactivate tracking ('1' or '0')
$rapidtrk = '1';

//add or remove ga script ('1' to add, '0' to remove)
$googleAnalytics = '0';

//add or remove yamads script ('1' to add, '0' to remove)
$yamadsSDK = '0';

// true to show quiz, anything else to remove quiz
$quiz = true;

?>