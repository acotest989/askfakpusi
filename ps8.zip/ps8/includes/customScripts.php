<style type="text/css">
  <? if (in_array($_country, array('hu'))) : ?>
    .list_box {

    max-width: 403px;
  }

  <? endif; ?><? if (in_array($_country, array('cz'))) : ?>
    .list_box {

    max-width: 334px;
  }

  <? endif; ?><? if (in_array($_country, array('sk'))) : ?>
    .list_box {

    max-width: 358px;
  }

  <? endif; ?><? if (in_array($_country, array('pl'))) : ?>
    .list_box {
      max-width: 410px;
    
  }

  <? endif; ?>
  <? if (in_array($_country, array('pt'))) : ?>.list_box {
    max-width: 370px;
  }

  <? endif; ?><? if (in_array($_country, array('ro'))) : ?>
    .list_box {

    max-width: 391px;

  }

  <? endif; ?><? if (in_array($_country, array('ee'))) : ?>
    .list_box {

    max-width: 381px;
  }

  <? endif; ?><? if (in_array($_country, array('lt'))) : ?>
    .list_box {

    max-width: 387px;
  }

  <? endif; ?><? if (in_array($_country, array('lv'))) : ?>.list_box {

    max-width: 351px;
  }


  <? endif; ?><? if (in_array($_country, array('gr'))) : ?>.list_box {

    max-width: 369px;
  }

  <? endif; ?>
</style>