<?php
			$url = 'http://'.$_SERVER["HTTP_HOST"].str_replace(basename ($_SERVER["SCRIPT_FILENAME"]),"",$_SERVER["REQUEST_URI"]);
			$keyword ='CAO DATE';
			$number ='091 81 43 01';
			$price ='2.00 KM + PDV za sve mreže';
			$tosurl ='http://seks.ba/u';
			$affiliate='http://thorcash.com/';
?>