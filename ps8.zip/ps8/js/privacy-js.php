<?php

    header("Content-type: text/javascript; charset: UTF-8");
    include '/var/www/sites/cms/dating/centralization/js/privacy.js';

?>