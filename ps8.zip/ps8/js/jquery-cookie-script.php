<?php
	header("Content-type: text/javascript; charset: UTF-8");
	include '/var/www/sites/cms/dating/centralization/js/jquery.cookie.1.4.1.min.js';
?>